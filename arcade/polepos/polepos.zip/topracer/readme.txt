POLE POSITION  (Bootleg)
Namco  1988

Main CPU : 3 Z80
Sound    : 3 POKEY ????

Dumped for you by Any (tandrea@hotmail.com),
delivered by Zolla (zollazolla@hotmail.com).


October 18, 1998.

Posit.          Function

TR 11 B		Sound ???

TR 15		Don't know
TR 16		"

TR 1 B		\  Z80 1 programm ???
TR 2 B		/

TR 5 B		\  Z80 2 programm ??
TR 6 B		/

TR 9 B		\  Z80 3 programm ??
10		/

1 2 3		Z80 adress??? missing prom

4 5  		other prom

All that stuff is on a board labeled CPU1
The restant part is on an other board called CPU2


PP17		Don't know

TR19		"

TR21		"

TRUS25		"

TRUS26		"

PP18		"

TR20		"

TR22		"

TR27		"

TR30		"

TR31		"

TR32		"

TR28		"

TR29		"

7 8 9 10p
11 13 14
15 16 17 	More prom