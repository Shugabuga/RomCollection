This archive contains the ROMs from a pirate Robocop board. 

For more information on this game, visit <http://www.zws.com/arcade/>.
