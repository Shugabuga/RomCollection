Cops 'N Robbers (Atari 1976)


5778

5779    5770    5782      5768

5780

5781                                5777

                                    5776         5766
                                    
                                    5775         5767
                                    
                                    5774         5765
                                    
                                    5773
                                    
                          5769      5772         6502     6820
                                    
                                    5771


005765-01       prom, uP enable (82S123)        H8
005766-01       prom, enable a  (82S123)        K8
005767-01       prom, enable b  (82S123)        J8
005768-01       prom, horizontal(82S129)        N4
005769-01       prom, vertical (82S129)         D5
005770-01       prom, center field obj (82S129) M2
005771-01       prom, program 7 (82S115)        B7
005772-01	prom, program 6 (82S115)	D7
005773-01	prom, program 5                 E7
005774-01       prom, program 4                 H7
005775-01       prom, program 3                 J7
005776-01       prom, program 2                 K7
005777-01       prom, program 1                 L7
005778-01       prom, player 1                  P1
005779-01       prom, player 2                  M1
005780-01       prom, player 3                  L1
005781-01       prom, player 4                  J1
005782-01       alpha numerics (82S115)         M3

